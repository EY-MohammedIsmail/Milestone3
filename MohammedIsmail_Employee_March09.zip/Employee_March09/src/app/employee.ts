export class Employee {
    //to provide the data fields
    id:number=0;    
    employeeName:string="";
    address:string="";
    phone:number=0;
    country:string="";
}
