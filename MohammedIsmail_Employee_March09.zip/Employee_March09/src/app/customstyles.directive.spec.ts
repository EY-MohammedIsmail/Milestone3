import { CustomstylesDirective } from './customstyles.directive';

describe('CustomstylesDirective', () => {
  it('should create an instance', () => {
    const directive = new CustomstylesDirective();
    expect(directive).toBeTruthy();
  });
});
